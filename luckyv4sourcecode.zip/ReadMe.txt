DO NOT COPY THIS SCRIPT BY CLAIMING THIS IS YOURS, THIS IS MADE BY YOUERAG

youtube.com/@youerag
tiktok.com/youerag
raggy#7073