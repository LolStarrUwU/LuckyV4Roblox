
local ScrollingFrame = Instance.new("ScrollingFrame")
local DaHood = Instance.new("TextButton")
local Bedwars = Instance.new("TextButton")
local TextLabel = Instance.new("TextLabel")
local BloxFruits = Instance.new("TextButton")
local Skywars = Instance.new("TextButton")
local AnyObby = Instance.new("TextButton")
local WorkAtAPizzaPlace = Instance.new("TextButton")


ScrollingFrame.Parent = game.StarterGui.ScreenGui
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(202, 254, 255)
ScrollingFrame.Position = UDim2.new(-1.49011612e-08, 0, 0.728244245, 0)
ScrollingFrame.Size = UDim2.new(0, 306, 0, 166)

DaHood.Name = "DaHood"
DaHood.Parent = ScrollingFrame
DaHood.BackgroundColor3 = Color3.fromRGB(210, 245, 255)
DaHood.Position = UDim2.new(0, 0, 0.0488549657, 0)
DaHood.Size = UDim2.new(0, 293, 0, 56)
DaHood.Font = Enum.Font.SourceSans
DaHood.Text = "Da hood"
DaHood.TextColor3 = Color3.fromRGB(0, 0, 0)
DaHood.TextSize = 14.000
DaHood.MouseButton1Down:connect(function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/Dimag16/DimagX_NEW/main/dimagx', true))()
end)

Bedwars.Name = "Bedwars"
Bedwars.Parent = ScrollingFrame
Bedwars.BackgroundColor3 = Color3.fromRGB(210, 245, 255)
Bedwars.Position = UDim2.new(0, 0, 0.0916030556, 0)
Bedwars.Size = UDim2.new(0, 293, 0, 56)
Bedwars.Font = Enum.Font.SourceSans
Bedwars.Text = "Bedwars"
Bedwars.TextColor3 = Color3.fromRGB(0, 0, 0)
Bedwars.TextSize = 14.000
Bedwars.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/main/NewMainScript.lua", true))()
end)

TextLabel.Parent = ScrollingFrame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.Position = UDim2.new(0.150326803, 0, 0, 0)
TextLabel.Size = UDim2.new(0, 200, 0, 50)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Lucky V4"
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextScaled = true
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true

BloxFruits.Name = "BloxFruits"
BloxFruits.Parent = ScrollingFrame
BloxFruits.BackgroundColor3 = Color3.fromRGB(210, 245, 255)
BloxFruits.Position = UDim2.new(0, 0, 0.134351149, 0)
BloxFruits.Size = UDim2.new(0, 293, 0, 56)
BloxFruits.Font = Enum.Font.SourceSans
BloxFruits.Text = "Blox fruits"
BloxFruits.TextColor3 = Color3.fromRGB(0, 0, 0)
BloxFruits.TextSize = 14.000
BloxFruits.MouseButton1Down:connect(function()
	loadstring(game:HttpGet"https://raw.githubusercontent.com/xDepressionx/Free-Script/main/AllScript.lua")()
end)


Skywars.Name = "Skywars"
Skywars.Parent = ScrollingFrame
Skywars.BackgroundColor3 = Color3.fromRGB(210, 245, 255)
Skywars.Position = UDim2.new(0, 0, 0.177099243, 0)
Skywars.Size = UDim2.new(0, 293, 0, 56)
Skywars.Font = Enum.Font.SourceSans
Skywars.Text = "Skywars"
Skywars.TextColor3 = Color3.fromRGB(0, 0, 0)
Skywars.TextSize = 14.000
Skywars.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://paste.ee/r/r9gnA", true))()
end)


AnyObby.Name = "AnyObby"
AnyObby.Parent = ScrollingFrame
AnyObby.BackgroundColor3 = Color3.fromRGB(210, 245, 255)
AnyObby.Position = UDim2.new(0, 0, 0.219847336, 0)
AnyObby.Size = UDim2.new(0, 293, 0, 56)
AnyObby.Font = Enum.Font.SourceSans
AnyObby.Text = "Any obby"
AnyObby.TextColor3 = Color3.fromRGB(0, 0, 0)
AnyObby.TextSize = 14.000
AnyObby.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/qYMFtFnV", true))()
end)

WorkAtAPizzaPlace.Name = "WorkAtAPizzaPlace"
WorkAtAPizzaPlace.Parent = ScrollingFrame
WorkAtAPizzaPlace.BackgroundColor3 = Color3.fromRGB(210, 245, 255)
WorkAtAPizzaPlace.Position = UDim2.new(-0.00326797389, 0, 0.262595415, 0)
WorkAtAPizzaPlace.Size = UDim2.new(0, 293, 0, 56)
WorkAtAPizzaPlace.Font = Enum.Font.SourceSans
WorkAtAPizzaPlace.Text = "Work at a pizza place"
WorkAtAPizzaPlace.TextColor3 = Color3.fromRGB(0, 0, 0)
WorkAtAPizzaPlace.TextSize = 14.000
WorkAtAPizzaPlace.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/tLqnPLN3",true))()
end)